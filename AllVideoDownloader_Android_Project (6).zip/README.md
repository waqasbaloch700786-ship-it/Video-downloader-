# AllVideoDownloader (com.waqas.downloader)

Complete Android Studio project with **Google AdMob**, **StartApp**, **ExoPlayer**, and **Background DownloadManager**.

- **Package Name**: `com.waqas.downloader`
- **AdMob App ID**: `ca-app-pub-5956721462213427~1020362142`
- **AdMob Interstitial ID**: `ca-app-pub-5956721462213427/4805537794`
- **StartApp App ID**: `209711096`

---

## 1. Automated APK Build via GitHub Actions (Recommended)
1. Push this project to any GitHub repository.
2. Go to the **Actions** tab on GitHub.
3. The workflow `.github/workflows/build-apk.yml` automatically compiles:
   - `AllVideoDownloader-Release-APK`
   - `AllVideoDownloader-Debug-APK`
4. Download the ready-to-install `.apk` file from the **Artifacts** section!

---

## 2. Local Build via Android Studio
1. Open this folder in **Android Studio (Ladybug or newer)**.
2. Wait for Gradle sync to complete.
3. Connect your Android phone with **USB Debugging** enabled.
4. Click **Run 'app'** (`Shift + F10`) to install directly.
5. To generate a signed release APK:
   - Go to **Build > Generate Signed Bundle / APK...**
   - Select **APK**, choose your Keystore, and select **release**.
   - APK output: `app/build/outputs/apk/release/app-release.apk`.

---

## 3. Command Line Build
```bash
# Build Debug APK
./gradlew assembleDebug

# Build Release APK
./gradlew assembleRelease
```
