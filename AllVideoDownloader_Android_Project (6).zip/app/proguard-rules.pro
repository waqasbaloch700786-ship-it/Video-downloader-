# Google AdMob Proguard rules
-keep class com.google.android.gms.ads.** { *; }
-dontwarn com.google.android.gms.ads.**

# StartApp In-App SDK Proguard rules
-keep class com.startapp.** { *; }
-dontwarn com.startapp.**

# Media3 / ExoPlayer rules
-keep class androidx.media3.** { *; }
-dontwarn androidx.media3.**
