package com.waqas.downloader

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.waqas.downloader.downloader.DownloadForegroundService
import com.waqas.downloader.monetization.AdMobManager
import com.waqas.downloader.monetization.StartAppManager
import com.waqas.downloader.ui.theme.AllVideoDownloaderTheme

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Handle shared URL from external apps (YouTube, browser, etc.)
        val sharedUrl = handleIncomingIntent(intent)

        setContent {
            AllVideoDownloaderTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    MainScreen(
                        initialUrl = sharedUrl,
                        onStartDownload = { url, fileName ->
                            val serviceIntent = Intent(this@MainActivity, DownloadForegroundService::class.java).apply {
                                putExtra("URL", url)
                                putExtra("FILE_NAME", fileName)
                            }
                            startService(serviceIntent)

                            // Show ad at natural transition point
                            AdMobManager.showInterstitial(this@MainActivity)
                        }
                    )
                }
            }
        }
    }

    private fun handleIncomingIntent(intent: Intent?): String? {
        if (intent?.action == Intent.ACTION_SEND && intent.type == "text/plain") {
            return intent.getStringExtra(Intent.EXTRA_TEXT)
        }
        return null
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(
    initialUrl: String?,
    onStartDownload: (url: String, fileName: String) -> Unit
) {
    var urlText by remember { mutableStateOf(initialUrl ?: "") }
    var statusMessage by remember { mutableStateOf("Ready to download public HD videos") }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("All Video Downloader HD") },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                    titleContentColor = MaterialTheme.colorScheme.onPrimaryContainer
                )
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            OutlinedTextField(
                value = urlText,
                onValueChange = { urlText = it },
                label = { Text("Enter Video URL") },
                placeholder = { Text("https://...") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )

            Button(
                onClick = {
                    if (urlText.isNotBlank()) {
                        val fileName = "video_${System.currentTimeMillis()}.mp4"
                        onStartDownload(urlText.trim(), fileName)
                        statusMessage = "Downloading: $fileName in background"
                    }
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Download Video (1080p / 720p)")
            }

            Text(
                text = statusMessage,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}