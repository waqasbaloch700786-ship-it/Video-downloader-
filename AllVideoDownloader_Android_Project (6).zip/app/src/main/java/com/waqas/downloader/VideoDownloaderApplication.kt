package com.waqas.downloader

import android.app.Application
import android.util.Log
import com.waqas.downloader.monetization.AdMobManager
import com.waqas.downloader.monetization.StartAppManager

class VideoDownloaderApplication : Application() {

    override fun onCreate() {
        super.onCreate()
        Log.d("AllVideoDownloader", "Application started: package com.waqas.downloader")

        // Initialize Google AdMob SDK
        AdMobManager.initialize(this)

        // Initialize StartApp SDK
        StartAppManager.initialize(this, testAds = true)
    }
}