package com.waqas.downloader.monetization

import android.app.Activity
import android.content.Context
import android.util.Log
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback

object AdMobManager {
    private const val TAG = "AdMobManager"
    
    // Official User Configured IDs
    const val APP_ID = "ca-app-pub-5956721462213427~1020362142"
    const val AD_UNIT_ID = "ca-app-pub-5956721462213427/4805537794"
    // Google official test ad unit for safe development
    const val TEST_AD_UNIT_ID = "ca-app-pub-3940256099942544/1033173712"

    private var interstitialAd: InterstitialAd? = null
    private var isLoading = false
    private var lastAdShowTime: Long = 0
    private const val COOLDOWN_INTERVAL_MS = 45_000L

    fun initialize(context: Context, onInitialized: () -> Unit = {}) {
        MobileAds.initialize(context) { status ->
            Log.d(TAG, "AdMob SDK Initialized: $status")
            loadInterstitial(context)
            onInitialized()
        }
    }

    fun loadInterstitial(context: Context, useTestAd: Boolean = false) {
        if (isLoading || interstitialAd != null) return
        isLoading = true

        val targetUnitId = if (useTestAd) TEST_AD_UNIT_ID else AD_UNIT_ID
        val adRequest = AdRequest.Builder().build()

        InterstitialAd.load(context, targetUnitId, adRequest, object : InterstitialAdLoadCallback() {
            override fun onAdLoaded(ad: InterstitialAd) {
                Log.d(TAG, "AdMob Interstitial loaded successfully.")
                interstitialAd = ad
                isLoading = false

                ad.fullScreenContentCallback = object : FullScreenContentCallback() {
                    override fun onAdDismissedFullScreenContent() {
                        interstitialAd = null
                        lastAdShowTime = System.currentTimeMillis()
                        loadInterstitial(context, useTestAd)
                    }

                    override fun onAdFailedToShowFullScreenContent(adError: AdError) {
                        Log.e(TAG, "AdMob show error: ${adError.message}")
                        interstitialAd = null
                        isLoading = false
                    }
                }
            }

            override fun onAdFailedToLoad(loadAdError: LoadAdError) {
                Log.e(TAG, "AdMob load error: ${loadAdError.message}")
                interstitialAd = null
                isLoading = false
            }
        })
    }

    fun showInterstitial(
        activity: Activity,
        isDownloadingOrPlaying: Boolean = false,
        onComplete: () -> Unit = {}
    ): Boolean {
        if (isDownloadingOrPlaying) {
            onComplete()
            return false
        }

        val now = System.currentTimeMillis()
        if (now - lastAdShowTime < COOLDOWN_INTERVAL_MS) {
            onComplete()
            return false
        }

        return if (interstitialAd != null) {
            interstitialAd?.show(activity)
            true
        } else {
            loadInterstitial(activity)
            onComplete()
            false
        }
    }
}