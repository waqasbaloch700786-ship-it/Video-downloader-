@rem Gradle startup script for Windows
@rem Execute gradle wrapper jar
@set DIRNAME=%~dp0
@java -jar "%DIRNAME%gradle\wrapper\gradle-wrapper.jar" %*
